﻿namespace Sudoku
{
    public class Box : Field
    {
    }
}