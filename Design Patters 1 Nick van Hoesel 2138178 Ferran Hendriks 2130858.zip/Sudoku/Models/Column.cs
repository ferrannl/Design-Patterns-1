﻿namespace Sudoku
{
    public class Column : Field
    {
    }
}