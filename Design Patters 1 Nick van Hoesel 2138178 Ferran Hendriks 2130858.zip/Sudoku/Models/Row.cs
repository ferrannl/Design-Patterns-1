﻿namespace Sudoku
{
    public class Row : Field
    {
    }
}