﻿namespace Sudoku
{
    public interface IState
    {
        string StateInfo();
    }
}