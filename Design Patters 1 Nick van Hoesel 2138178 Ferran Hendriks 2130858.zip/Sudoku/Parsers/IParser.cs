﻿namespace Sudoku
{
    public interface IParser
    {
        Board GenerateBoard();
    }
}